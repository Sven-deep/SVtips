﻿--显示职业
hooksecurefunc("UnitFramePortrait_Update",function(self) 
   if self.portrait then 
      if UnitIsPlayer(self.unit) then         
         local t = CLASS_ICON_TCOORDS[select(2,UnitClass(self.unit))] 
         if t then 
            self.portrait:SetTexture("Interface\\TargetingFrame\\UI-Classes-Circles") 
            self.portrait:SetTexCoord(unpack(t)) 
         end 
      else 
         self.portrait:SetTexCoord(0,1,0,1) 
      end 
   end 
end);

--隐藏头像伤害显示
local p=PlayerHitIndicator;p.Show=p.Hide;p:Hide() 
local p=PetHitIndicator;p.Show=p.Hide;p:Hide()


-- 隐藏自带boss框体 Remove standard Boss frames 
for i = 1,MAX_BOSS_FRAMES do 
   local t_boss = _G["Boss"..i.."TargetFrame"] 
   t_boss:UnregisterAllEvents() 
   t_boss.Show = dummy 
   t_boss:Hide() 
   _G["Boss"..i.."TargetFrame".."HealthBar"]:UnregisterAllEvents() 
   _G["Boss"..i.."TargetFrame".."ManaBar"]:UnregisterAllEvents() 
end

--------------------------- 
--[重载命令]
SlashCmdList["RELOADUI"] = function() ReloadUI() end
SLASH_RELOADUI1 = "/rl" 


--隐藏动作条两边的老鹰
--MainMenuMaxLevelBar0:Hide() 
--MainMenuMaxLevelBar1:Hide() 
--MainMenuMaxLevelBar3:Hide() 
--MainMenuMaxLevelBar2:Hide() 
--MainMenuBarTexture0:Hide() 
--MainMenuBarTexture1:Hide() 
--MainMenuBarTexture2:Hide() 
--MainMenuBarTexture3:Hide() 
--MainMenuBarLeftEndCap:Hide()
--MainMenuBarRightEndCap:Hide()



--[打断施法喊话] 
local AfterInterrupt = CreateFrame("Frame", nil, UIParent) 
AfterInterrupt:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED") 
local function InterruptUpdate(self, event, ...) 
   if event == "COMBAT_LOG_EVENT_UNFILTERED" then       
      local timestamp, eventType, _, sourceGUID, sourceName, sourceFlags, sourceRaidFlags, destGUID, destName, destFlags, _, spellID, spellName, _, extraskillID, extraSkillName = ... 
      if eventType == "SPELL_INTERRUPT" and sourceName == UnitName("player") then 
         SendChatMessage("已打断--"..GetSpellLink(extraskillID), "YELL")--喊频道修改 
      end 
   end 
end 
AfterInterrupt:SetScript("OnEvent", InterruptUpdate) 