﻿--[施法条计时及图标] 
local CASTBAR_ICON = true -- show ico and time of cast bar 施法条 

local CAST_SHOW = CASTBAR_ICON 



--player casting bar 玩家施法条 
CastingBarFrame.Icon:Show() 
CastingBarFrame.Icon:SetHeight( 25 ) 
CastingBarFrame.Icon:SetWidth( 25 ) 
CastingBarFrame.Icon:ClearAllPoints() 
CastingBarFrame.Icon:SetPoint( "RIGHT", CastingBarFrame, "LEFT", -8, 2.5 ) 

CastingBarFrame:ClearAllPoints() 
CastingBarFrame:SetPoint("CENTER",UIParent,"CENTER",0,-200) 
CastingBarFrame.SetPoint = function() end 

-- Castbar timer from thek 施法条计时器 
CastingBarFrame.timer = CastingBarFrame:CreateFontString(nil) 
CastingBarFrame.timer:SetFont("Fonts\\ARIALN.ttf", 18, "THINOUTLINE") 
CastingBarFrame.timer:SetPoint("LEFT", CastingBarFrame, "RIGHT", 10, 2.5) 
CastingBarFrame.update = .1 

TargetFrameSpellBar.timer = TargetFrameSpellBar:CreateFontString(nil) 
TargetFrameSpellBar.timer:SetFont("Fonts\\ARIALN.ttf", 13, "THINOUTLINE") 
TargetFrameSpellBar.timer:SetPoint("LEFT", TargetFrameSpellBar, "RIGHT", 5, 0) 
TargetFrameSpellBar.update = .1 

FocusFrameSpellBar.timer = FocusFrameSpellBar:CreateFontString(nil) 
FocusFrameSpellBar.timer:SetFont("Fonts\\ARIALN.ttf", 13, "THINOUTLINE") 
FocusFrameSpellBar.timer:SetPoint("LEFT", FocusFrameSpellBar, "RIGHT", 5, 0) 
FocusFrameSpellBar.update = .1 

local function CastingBarFrame_OnUpdate_Hook(self, elapsed)
   if not self.timer then return end
   if self.update and self.update < elapsed then
      if self.casting then
         self.timer:SetText(format("%.1f", max(self.maxValue - self.value, 0)))
      elseif self.channeling then
         self.timer:SetText(format("%.1f", max(self.value, 0)))
      else
         self.timer:SetText("")
      end
      self.update = .1
   else
      self.update = self.update - elapsed
   end
end

CastingBarFrame:HookScript('OnUpdate', CastingBarFrame_OnUpdate_Hook) 
