### Version 7.0.3.2

- Fixed Masque support
- Fixed options dropdowns appearing behind other frames

### Version 7.0.3.1

- Fixed the options panel
- Fixed an error that occasionally happened when zoning or finishing a flight path

### Version 7.0.3.0

- Updated for WoW 7.0
