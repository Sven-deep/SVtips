﻿-- Config
local guildRepair = true -- Use guild repair
local guildOnlyRaid = false -- Guild repair only while in a raid group

--  The goods
local rm = CreateFrame("Frame", "RepairMe")
rm:RegisterEvent("MERCHANT_SHOW")
rm:SetScript("OnEvent", function()
	local cost = GetRepairAllCost()
	local function gr()
		if cost > 1e4 then
			print(format("COST[GB] %d|cffffd700g|r %d|cffc7c7cfs|r %d|cffeda55fc|r", cost / 1e4, mod(cost, 1e4) / 1e2, mod(cost, 1e2)))
		elseif cost > 1e2 then
			print(format("COST[GB] %d|cffc7c7cfs|r %d|cffeda55fc|r", cost / 1e2, mod(cost, 1e2)))
		else
			print(format("COST[GB] %d|cffeda55fc|r", cost))
		end
		RepairAllItems(1)
	end
	local function sr()
		if cost > 1e4 then
			print(format("COST %d|cffffd700g|r %d|cffc7c7cfs|r %d|cffeda55fc|r", cost / 1e4, mod(cost, 1e4) / 1e2, mod(cost, 1e2)))
		elseif cost > 1e2 then
			print(format("COST %d|cffc7c7cfs|r %d|cffeda55fc|r", cost / 1e2, mod(cost, 1e2)))
		else
			print(format("COST %d|cffeda55fc|r", cost))
		end
		RepairAllItems()
	end
	if IsModifierKeyDown() then
		return
	elseif CanMerchantRepair() and cost ~= 0 then
		if guildRepair and CanGuildBankRepair() and cost <= GetGuildBankMoney() and (cost <= GetGuildBankWithdrawMoney() or GetGuildBankWithdrawMoney() == -1) then
			if guildOnlyRaid and GetNumRaidMembers() ~= 0 then
				gr()
			elseif not guildOnlyRaid then
				gr()
			elseif cost <= GetMoney() then
				sr()
			else
				print("Not enough money")
			end
		elseif cost <= GetMoney() then
			sr()
		else
			print("Not enough money")
		end
	end
end)

--Autosell
local frame = CreateFrame('Frame') 
frame:RegisterEvent('MERCHANT_SHOW') 
frame:SetScript('OnEvent', function (frame, event, ...) 
  if event == 'MERCHANT_SHOW' then 
    local link 
    for bag = 0, 4 do 
      for slot = 0, GetContainerNumSlots(bag) do 
        link = GetContainerItemLink(bag, slot) 
        if link and select(3, GetItemInfo(link)) == 0 then 
          ShowMerchantSellCursor(1) 
          UseContainerItem(bag, slot) 
        end 
      end 
    end 
  end 
end)





--帧数延迟时间耐久内存综合显示 
--帧数延迟时间耐久内存综合显示 
local cfg={ 
   color = {255/255, 207/255, 164/255},--默认颜色 
   classcolor = true,   --使用职业染色 
   font = STANDARD_TEXT_FONT,   --"Fonts\\ARIALN.ttf" 字体 
   fontstyle = nil,   --"THINOUTLINE", "OUTLINE MONOCHROME", "OUTLINE" or nil (no outline)字体样式 
   font_s = 17,   --小字体大小 
   font_m = 20,   --位置文字字体大小 
   font_l = 20,   --时间文字字体大小 
   scale = 1,   --整体的缩放 
   } 
local r,g,b=unpack(cfg.color) 
if cfg.classcolor then 
   local color=RAID_CLASS_COLORS[select(2, UnitClass("player"))] 
   r,g,b=color.r,color.g,color.b 
end 

local DataFrame = CreateFrame("Frame","DataFrame",UIParent) 
DataFrame:SetScript('OnEvent', function(self, event, ...) self[event](self, ...) end) 
DataFrame:RegisterEvent('PLAYER_LOGIN') 
DataFrame:SetFrameStrata("LOW") 
DataFrame:SetSize(185,30) 
DataFrame:SetPoint("TOPRIGHT",UIParent,"TOPRIGHT",-120,-50)   --位置 
DataFrame:SetScale(cfg.scale) 


local Frames = {fps = {},latency={},durability = {},memory={},thetime = {},zone = {},} 
local Texts = {fps,latency,durability,memory,thetime,zone} 
local Data = {fps,latency,durability,memory,thetime,zone} 
--postion 
local Postion={ 
            fps = {"TOP",DataFrame,"TOP",0,0}, 
            latency={"TOP",DataFrame,"TOP",0,-20}, 
            durability = {"TOP",DataFrame,"TOP",0,-40}, 
            memory={"TOP",DataFrame,"TOP",0,-60}, 
            thetime = {"TOP",DataFrame,"TOP",10,-70}, 
            zone = {"TOP",DataFrame,"BOTTOM",0,0}, 
            }             
--==   elements fuctions   ==-- 

-- durability 
local durabilityval=function() 
   local durability,n=0,0 
   for i = 1,20 do 
      if GetInventoryItemDurability(i) ~= nil then 
         local dur, max = GetInventoryItemDurability(i) 
         local percent = dur / max * 100 
         durability = durability + percent 
         n = n+1 
      end       
   end 
   durability = floor(durability/n) 
   return durability 
end 


--memory 
local memoryval=function(val) 
   return format(format("%%.%df %s",dec or 1,val > 1024 and "MB" or "KB"),val/(val > 1024 and 1024 or 1)) 
end 


----------------------------------- 

local function CreateElements() 
   for k,v in pairs(Frames,Texts,Data,Postion) do 
      Frames[k]=CreateFrame("Frame","Data_"..k.."_Frame",DataFrame) 
      Frames[k]:SetFrameStrata("LOW") 
      -- enableMouse 
      Frames[k]:EnableMouse(true) 
      if Frames[k] == Frames.thetime then 
         Frames[k]:SetScript("OnMouseDown",thetime_onClick) 
      elseif Frames[k] == Frames.durability then 
         Frames[k]:SetScript("OnEnter",durability_onEnter) 
      elseif Frames[k] == Frames.zone then 
         Frames[k]:SetScript("OnMouseDown", zone_onClick) 
      elseif Frames[k] == Frames.memory then 
         Frames[k]:SetScript("OnMouseDown", memory_onClick) 
         Frames[k]:SetScript("OnEnter", memory_onEnter) 
      end 
      Frames[k]:SetScript('OnLeave', function() GameTooltip:Hide() end) 
      --size 
      if Frames[k] == Frames.thetime then 
         Frames[k]:SetSize(90,39) 
      elseif Frames[k] == Frames.zone then 
         Frames[k]:SetSize(90,23) 
      else 
         Frames[k]:SetSize(53,13) 
      end 
      --point 
      Frames[k]:SetPoint(unpack(Postion[k])) 
       
      --text 
      Texts[k] = Frames[k]:CreateFontString(nil,"OVERLAY") 
      if Texts[k] == Texts.thetime then 
         Texts[k]:SetFont(cfg.font, cfg.font_l , cfg.fontstyle) 
         Texts[k]:SetJustifyH("LEFT") 
         Texts[k]:SetPoint("LEFT",Frames[k],"LEFT",0,0) 
      elseif Texts[k] == Texts.zone then 
         Texts[k]:SetFont(cfg.font, cfg.font_m , cfg.fontstyle) 
         Texts[k]:SetJustifyH("RIGHT")   
         Texts[k]:SetPoint("RIGHT",Frames[k],"RIGHT",0,0)         
      else 
         Texts[k]:SetFont(cfg.font, cfg.font_s , cfg.fontstyle) 
         Texts[k]:SetJustifyH("RIGHT") 
         Texts[k]:SetPoint("RIGHT",Frames[k],"RIGHT",0,0) 
      end 
      Texts[k]:SetText(Data[k]) 
      Texts[k]:SetTextColor(r,g,b) 
      Texts[k]:SetShadowOffset(0, 0) 
   end 
end 

local function GetData() 
   Data.fps = GetFramerate() 
   Data.fps = floor(Data.fps).." fps" 
   
   Data.latency = select(3, GetNetStats()) 
   Data.latency = Data.latency.." ms" 
   
   Data.durability = durabilityval().."%" 
   Data.memory = memoryval(collectgarbage("count")) 
   
   Data.thetime = date("%H:%M") 

end 

local function Output() 
   for k,v in pairs(Frames,Texts,Data) do 
        Texts[k]:SetText(Data[k]) 
    end 
end 


function DataFrame:PLAYER_LOGIN() 
   CreateElements() 
end 

DataFrame:SetScript("OnUpdate", function(self, elapsed) 
        if self.lt== nil then self.lt=0 end 
        self.lt = self.lt + elapsed 
        if self.lt > 1 then 
            GetData() 
         Output() 
            self.lt=0 
        end 
    end)

	


